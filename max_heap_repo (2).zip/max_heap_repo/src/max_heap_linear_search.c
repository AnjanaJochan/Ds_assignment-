/*
 * Question: Identify the highest student score.
 * Data: 78, 92, 65, 88, 95, 72, 84, 90
 *
 * a) Implement a Max Heap and insert all the scores.
 *    Print the heap array after every insertion.
 * b) Find the highest score using:
 *      - Max Heap   (root of the heap)
 *      - Linear Search (scan the plain array)
 *    Count and print the number of comparisons/operations for each.
 * c) Also demonstrate inserting ONE new score (99) into both structures
 *    to compare insertion cost + cost of finding the max afterwards.
 *
 * Compile: gcc max_heap_linear_search.c -o max_heap_linear_search
 * Run:     ./max_heap_linear_search
 */

#include <stdio.h>

#define MAX_N 100

/* ---------------- Max Heap (array based) ---------------- */
int heap[MAX_N];
int heapSize = 0;

void printHeap(void) {
    printf("[ ");
    for (int i = 0; i < heapSize; i++) printf("%d ", heap[i]);
    printf("]\n");
}

/* Insert one value into the max heap, sift-up (heapify-up).
 * Returns comparisons and swaps done, via pointers. */
void heapInsert(int value, int *cmpCount, int *swapCount) {
    int cmp = 0, swp = 0;

    heap[heapSize] = value;
    int i = heapSize;
    heapSize++;

    while (i > 0) {
        int parent = (i - 1) / 2;
        cmp++;                                  /* compare child vs parent */
        if (heap[i] > heap[parent]) {
            int t = heap[i];
            heap[i] = heap[parent];
            heap[parent] = t;
            swp++;
            i = parent;
        } else {
            break;
        }
    }
    *cmpCount = cmp;
    *swapCount = swp;
}

/* Finding the max in a max heap is just reading the root: O(1), 0 comparisons */
int heapFindMax(int *cmpCount) {
    *cmpCount = 0;
    return heap[0];
}

/* ---------------- Linear Search (plain array) ---------------- */
int linearFindMax(int arr[], int n, int *cmpCount) {
    int maxVal = arr[0];
    int cmp = 0;
    for (int i = 1; i < n; i++) {
        cmp++;                                  /* compare arr[i] with current max */
        if (arr[i] > maxVal) {
            maxVal = arr[i];
        }
    }
    *cmpCount = cmp;
    return maxVal;
}

int main(void) {
    int scores[] = {78, 92, 65, 88, 95, 72, 84, 90};
    int n = sizeof(scores) / sizeof(scores[0]);

    printf("Input scores: ");
    for (int i = 0; i < n; i++) printf("%d ", scores[i]);
    printf("\n\n");

    /* ---------- a) Build Max Heap by inserting all scores, one by one ---------- */
    printf("=== a) Max Heap construction (insert one score at a time) ===\n");
    int totalCmp = 0, totalSwap = 0;
    for (int i = 0; i < n; i++) {
        int cmp, swp;
        heapInsert(scores[i], &cmp, &swp);
        totalCmp += cmp;
        totalSwap += swp;
        printf("Insert %-3d -> comparisons: %d, swaps: %d, heap: ", scores[i], cmp, swp);
        printHeap();
    }
    printf("Total comparisons while building heap: %d\n", totalCmp);
    printf("Total swaps while building heap      : %d\n\n", totalSwap);

    /* ---------- b) Find the highest score : Max Heap vs Linear Search ---------- */
    printf("=== b) Finding the highest score ===\n");

    int heapCmp;
    int heapMax = heapFindMax(&heapCmp);
    printf("Max Heap      -> highest score = %d, comparisons used = %d (root read only)\n",
           heapMax, heapCmp);

    int linCmp;
    int linMax = linearFindMax(scores, n, &linCmp);
    printf("Linear Search -> highest score = %d, comparisons used = %d\n\n", linMax, linCmp);

    /* ---------- c) Insert ONE new score and compare cost of update ---------- */
    printf("=== c) Inserting a new score (99) and finding the new maximum ===\n");

    /* c1: Max Heap insertion */
    int newCmp, newSwap;
    heapInsert(99, &newCmp, &newSwap);
    printf("Max Heap      -> insertion comparisons: %d, swaps: %d, heap: ", newCmp, newSwap);
    printHeap();
    int heapCmp2;
    int heapMax2 = heapFindMax(&heapCmp2);
    printf("Max Heap      -> new highest score = %d, comparisons to fetch it = %d\n",
           heapMax2, heapCmp2);
    printf("Max Heap      -> TOTAL cost (insert + fetch max) = %d comparisons\n\n",
           newCmp + heapCmp2);

    /* c2: Plain array insertion (append is O(1)), then re-scan for the max */
    int scores2[MAX_N];
    for (int i = 0; i < n; i++) scores2[i] = scores[i];
    scores2[n] = 99;
    int n2 = n + 1;
    printf("Linear Array  -> insertion comparisons: 0 (append at end), array: [ ");
    for (int i = 0; i < n2; i++) printf("%d ", scores2[i]);
    printf("]\n");
    int linCmp2;
    int linMax2 = linearFindMax(scores2, n2, &linCmp2);
    printf("Linear Array  -> new highest score = %d, comparisons to find it = %d\n",
           linMax2, linCmp2);
    printf("Linear Array  -> TOTAL cost (insert + re-scan for max) = %d comparisons\n\n",
           0 + linCmp2);

    return 0;
}
