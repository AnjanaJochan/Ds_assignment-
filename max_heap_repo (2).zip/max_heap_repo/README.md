# Max Heap vs Linear Search — Finding the Highest Student Score

**Input scores:** `78, 92, 65, 88, 95, 72, 84, 90`

This repo contains everything required by the assignment:

| Requirement | File |
|---|---|
| Source code | [`src/max_heap_linear_search.c`](src/max_heap_linear_search.c) |
| Input data | [`input/input.txt`](input/input.txt) |
| Output | [`output/output.txt`](output/output.txt) |
| Trace table | [`docs/trace_table.md`](docs/trace_table.md) |
| Complexity analysis | [`docs/complexity_analysis.md`](docs/complexity_analysis.md) |
| Comparison table | [`docs/comparison_table.md`](docs/comparison_table.md) |
| Final conclusion | [`docs/conclusion.md`](docs/conclusion.md) |

## What the program does

1. **(a)** Implements an array-based **Max Heap** and inserts all 8 scores one
   at a time, printing the heap array (and the comparisons/swaps used) after
   every single insertion.
2. **(b)** Finds the highest score two ways, counting comparisons for each:
   - **Max Heap** — read the root, O(1), 0 comparisons.
   - **Linear Search** — scan the plain array, O(n), 7 comparisons.
3. **(c)** Inserts one new score (`99`) into both structures to show how each
   one behaves when the data keeps growing: the heap re-settles in O(log n)
   and the max is instantly available; the array insert is O(1) but finding
   the new max again costs a full O(n) re-scan.

## How to run

```bash
cd src
gcc max_heap_linear_search.c -o max_heap_linear_search
./max_heap_linear_search
```

## Folder structure

```
.
├── src/
│   └── max_heap_linear_search.c
├── input/
│   └── input.txt
├── output/
│   └── output.txt
├── docs/
│   ├── trace_table.md
│   ├── complexity_analysis.md
│   ├── comparison_table.md
│   └── conclusion.md
└── README.md
```

## Result summary

| Metric | Max Heap | Linear Search |
|---|---|---|
| Comparisons to find the max | 0 | 7 |
| Comparisons to insert a new score + find new max | 3 | 8 |
| Find-max time complexity | O(1) | O(n) |
| Insert time complexity | O(log n) | O(1) |

**Conclusion:** the **Max Heap** is the more suitable data structure for
*continuously* maintaining the highest score, since it keeps the maximum
instantly retrievable (O(1)) while supporting cheap O(log n) updates as new
scores arrive. See [`docs/conclusion.md`](docs/conclusion.md) for full
justification.
