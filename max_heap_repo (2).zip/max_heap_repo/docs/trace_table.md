# Trace Tables

**Input scores:** 78, 92, 65, 88, 95, 72, 84, 90

## 1) Max Heap construction — insertion trace (sift-up / heapify-up)

Array is 0-indexed; for a node at index `i`, `parent = (i-1)/2`.

| Step | Insert | Comparisons | Swaps | Heap array after insertion |
|---|---|---|---|---|
| 1 | 78 | 0 | 0 | [78] |
| 2 | 92 | 1 | 1 | [92, 78] |
| 3 | 65 | 1 | 0 | [92, 78, 65] |
| 4 | 88 | 2 | 1 | [92, 88, 65, 78] |
| 5 | 95 | 2 | 2 | [95, 92, 65, 78, 88] |
| 6 | 72 | 2 | 1 | [95, 92, 72, 78, 88, 65] |
| 7 | 84 | 2 | 1 | [95, 92, 84, 78, 88, 65, 72] |
| 8 | 90 | 2 | 1 | [95, 92, 84, 90, 88, 65, 72, 78] |
| **Total** | — | **12** | **7** | |

Final max-heap array: `[95, 92, 84, 90, 88, 65, 72, 78]`

## 2) Finding the highest score

### Max Heap
The maximum in a max heap is always the root — no scanning or comparison needed.

| Step | Action | Comparisons |
|---|---|---|
| 1 | Read `heap[0]` | 0 |
| **Result** | **95** | **Total = 0** |

### Linear Search (over the plain array `78, 92, 65, 88, 95, 72, 84, 90`)

| Step | Compare | Current max | Comparisons so far |
|---|---|---|---|
| 0 | (initialize max = 78) | 78 | 0 |
| 1 | 92 > 78 → update | 92 | 1 |
| 2 | 65 > 92? no | 92 | 2 |
| 3 | 88 > 92? no | 92 | 3 |
| 4 | 95 > 92 → update | 95 | 4 |
| 5 | 72 > 95? no | 95 | 5 |
| 6 | 84 > 95? no | 95 | 6 |
| 7 | 90 > 95? no | 95 | 7 |
| **Result** | **95** | | **Total = 7** |

## 3) Inserting one new score (99) and re-establishing the maximum

### Max Heap: insert 99 into `[95, 92, 84, 90, 88, 65, 72, 78]`

| Step | Compare (child vs parent) | Swap? | Comparisons | Swaps |
|---|---|---|---|---|
| 1 | 99 (idx 8) vs 90 (idx 3, parent) | yes | 1 | 1 |
| 2 | 99 (idx 3) vs 92 (idx 1, parent) | yes | 1 | 1 |
| 3 | 99 (idx 1) vs 95 (idx 0, parent) | yes | 1 | 1 |
| **Total** | | | **3** | **3** |

Resulting heap: `[99, 95, 84, 92, 88, 65, 72, 78, 90]`
New max fetched from root: **99**, comparisons = **0**
**Total cost (insert + fetch max) = 3 comparisons**

### Plain Array: append 99 to `78, 92, 65, 88, 95, 72, 84, 90`

| Step | Action | Comparisons |
|---|---|---|
| 1 | Append 99 at the end (index 8) | 0 |
| 2 | Re-run linear search over all 9 elements to find the new max | 8 |
| **Total** | | **8** |

**Total cost (insert + re-scan for max) = 8 comparisons**
