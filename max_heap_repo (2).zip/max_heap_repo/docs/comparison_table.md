# Comparison: Max Heap vs Linear Search

## Execution results on the given data (78, 92, 65, 88, 95, 72, 84, 90)

| Criterion | Max Heap | Linear Search |
|---|---|---|
| Comparisons to build/scan structure once | 12 (over all 8 insertions) | 7 (single pass to find max) |
| Comparisons to **find** the maximum | **0** (root of heap) | 7 (must scan all n elements) |
| Result found | 95 | 95 |
| Comparisons to **insert** a new score (99) | 3 (sift-up, O(log n)) | 0 (simple append, O(1)) |
| Comparisons to find max **after** inserting 99 | 0 (root already updated) | 8 (must re-scan all n+1 elements) |
| Combined cost: insert + get max | **3** | 8 |
| Data structure used | Array-based complete binary tree | Plain 1-D array |
| Time complexity — find max | O(1) | O(n) |
| Time complexity — insert | O(log n) | O(1) |
| Time complexity — build from n items (one at a time) | O(n log n) | O(n) |
| Space complexity | O(n) | O(n) |
| Behaviour as scores keep arriving | Max always instantly available after each O(log n) insert | Every "who is highest now?" query costs a fresh O(n) scan |
| Best suited for | Continuously maintaining/querying the running maximum (leaderboards, priority queues, scheduling) | One-off / rare queries on data that changes rarely |

## Trend as the number of students (n) increases

| n (students) | Linear Search: comparisons per "find max" query | Max Heap: comparisons per insert (≈ log₂ n) | Max Heap: comparisons per "find max" query |
|---|---|---|---|
| 8 | 7 | ~3 | 0 |
| 100 | 99 | ~7 | 0 |
| 1,000 | 999 | ~10 | 0 |
| 100,000 | 99,999 | ~17 | 0 |

Linear search's cost per query grows **linearly** with n. The max heap's
insertion cost grows only **logarithmically** with n, and every query for the
current maximum stays at **O(1)** regardless of how large n gets.
