# Final Conclusion

Both methods correctly identify **95** as the highest score among
`78, 92, 65, 88, 95, 72, 84, 90`.

- **Linear Search** needed **7 comparisons** to find the maximum in the
  8-score array — a fresh O(n) scan every single time the maximum is asked
  for.
- **Max Heap** needed **12 comparisons in total** just to *build* the heap
  (one insertion at a time), but once built, reading the maximum costs
  **0 comparisons** — it is always sitting at the root.

## Behaviour under the three scenarios asked for

1. **Finding the maximum (one-off):**
   Linear search (O(n)) is actually cheaper than first building a heap
   (O(n log n)) if the maximum is needed only once and the data will not
   change again.

2. **Inserting a new score:**
   A heap insertion costs O(log n) (3 comparisons here, to insert 99), while
   a plain array append costs O(1) (0 comparisons). The array wins on pure
   insertion cost — but that new element makes the array's *stored* maximum
   stale, so finding the max afterwards forces another full O(n) scan (8
   comparisons here). The heap's O(log n) insertion, in contrast, leaves the
   correct maximum instantly available at the root (0 comparisons to fetch
   it). Combined cost: **heap = 3, array = 8**.

3. **Increasing the number of students (n):**
   As n grows, linear search's per-query cost grows linearly (O(n)) and gets
   worse every time the maximum is requested again. The heap's per-insert
   cost grows only logarithmically (O(log n)), and its per-query cost for the
   maximum stays constant at O(1) no matter how large n becomes.

## Recommendation

- Use **Linear Search** only when the score list is static and the maximum
  is needed just **once** (or very rarely) — no need to pay the overhead of
  building and maintaining a heap.
- Use a **Max Heap** whenever scores keep arriving over time and the
  **current highest score must be tracked continuously** (e.g., a live
  leaderboard, a running "topper" display, priority scheduling, or an
  exam-monitoring dashboard that updates as each student submits). The heap
  turns every future "who is highest?" query into an O(1) lookup at the cost
  of only an O(log n) update per new score — a trade that pays off
  increasingly as the number of students (and the number of queries) grows.

**Justification:** For continuously maintaining the highest score, the
**Max Heap is the more suitable data structure**, because it keeps the
maximum instantly accessible (O(1)) while still supporting cheap,
logarithmic-time updates (O(log n)) as new scores keep coming in — something
a plain array with linear search cannot match once queries become frequent.
