# Complexity Analysis

Let **n** = number of students (scores).

## Max Heap

- **Insertion of one element:** the new value is placed at the next free leaf and
  "sifted up" by comparing it with its parent at most `⌈log₂(n+1)⌉` times.
  → **Time complexity: O(log n)**
- **Building the whole heap by inserting n elements one at a time** (as required
  by part a of the question): n insertions, each O(log n).
  → **Time complexity: O(n log n)**
  *(Note: if the array were heapified all at once with the bottom-up
  `build-heap` algorithm instead of one-by-one insertion, that would be O(n).
  This assignment specifically asks for insertion-by-insertion, so O(n log n)
  is the correct bound here.)*
- **Finding the maximum:** the maximum of a max heap is always stored at the
  root, `heap[0]`.
  → **Time complexity: O(1)**
- **Space complexity:** O(n) to store n elements in the array-based heap.

## Linear Search (plain/unsorted array)

- **Insertion of one element:** simply append at the next free index.
  → **Time complexity: O(1)**
- **Finding the maximum:** every element must be inspected once since the
  array is not ordered in any useful way.
  → **Time complexity: O(n)**
- **Space complexity:** O(n) to store n elements.

## Summary

| Operation | Max Heap | Linear Search (array) |
|---|---|---|
| Insert 1 element | O(log n) | O(1) |
| Build structure from n elements (one at a time) | O(n log n) | O(n) |
| Find maximum | **O(1)** | O(n) |
| Find max *after* an insertion | O(1) (root already correct) | O(n) (must re-scan) |
| Space | O(n) | O(n) |

## Why this matters when the maximum is needed repeatedly

If the maximum is queried only **once**, linear search is cheaper overall
(O(n) once) than building a heap first (O(n log n)) just to get O(1) after.

But if scores keep arriving **continuously** and the current highest score
must be available **at any time**, the two approaches behave very differently
over `n` insertions and `m` "get max" queries:

- **Max Heap:** total cost ≈ `n × O(log n)` (insertions) + `m × O(1)` (queries)
- **Linear Search:** total cost ≈ `n × O(1)` (insertions) + `m × O(n)` (queries,
  each one a full re-scan)

As `m` (the number of times the max is asked for) grows, the linear-search
approach's cost grows as `O(m·n)`, while the heap's cost stays close to
`O(n log n + m)`. For any realistic scenario where the max is checked
frequently (e.g., after every new score, or on a live leaderboard), the heap
wins decisively as `n` and `m` increase.
